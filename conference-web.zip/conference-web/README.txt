Typography: 
- Google Font Roboto
Colours:
- Ultramarine Blue: #C70039
- Red: #354BF7
- White: #FFFFFF