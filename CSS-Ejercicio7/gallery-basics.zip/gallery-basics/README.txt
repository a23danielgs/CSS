Google fonts:
- Vina Sans
- Karla
Colours:
- Sepia: #6F3A1B
- Blue Sapphire: #1B506F